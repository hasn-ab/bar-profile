export const colors = {
  WHITE: 'white',
  BLACK: 'black',
  PURPLE: '#373DDE',
  TRANSPARENT_BLACK: 'rgba(0,0,0,0.4)',
  GREEN: '#20E700',
  PINK: '#FF3366',
};
