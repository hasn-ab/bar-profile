import {createContext} from 'react';

export const BarContext = createContext(null);
